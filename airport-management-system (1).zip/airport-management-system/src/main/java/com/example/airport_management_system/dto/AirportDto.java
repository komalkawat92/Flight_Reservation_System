package com.example.airport_management_system.dto;

import com.example.airport_management_system.entity.Feedback;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AirportDto {
    @Schema(description = "Unique identifier of the airport", example = "1",hidden = true)
    private Long airportId;

    @Schema(description = "Name of the airport", example = "Los Angeles International Airport")
    private String name;

    @Schema(description = "City where the airport is located", example = "Los Angeles")
    private String city;

    @Schema(description = "Country where the airport is located", example = "United States")
    private String country;

    @Schema(description = "Latitude coordinate of the airport", example = "33.9416")
    private Double latitude;

    @Schema(description = "Longitude coordinate of the airport", example = "-118.4085")
    private Double longitude;

    @Schema(description = "Number of terminals at the airport", example = "4")
    private Integer terminalCount;

    @Schema(hidden = true)
    private List<FeedbackDto> feedbacks;

}
