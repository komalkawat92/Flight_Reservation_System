package com.example.airport_management_system.controller;

import com.example.airport_management_system.dto.PageResponse;
import com.example.airport_management_system.dto.UserDto;
import com.example.airport_management_system.service.UserService;
import com.example.airport_management_system.util.FilterBuilderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.coyote.BadRequestException;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/user")
@Tag(name = "User API")
public class UserController {

    private final UserService userService;
    private final FilterBuilderService filterBuilderService;

    public UserController(UserService userService, FilterBuilderService filterBuilderService) {
        this.userService = userService;
        this.filterBuilderService = filterBuilderService;
    }


    @Operation(description = "Create or Signup User",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(),
            responses = @io.swagger.v3.oas.annotations.responses.ApiResponse
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200",
                    content = {@Content(schema = @Schema(implementation = String.class), mediaType = "application/json")}),
            @ApiResponse(responseCode = "401", content = {@Content(schema = @Schema(), mediaType = "application/json")}),
            @ApiResponse(responseCode = "500", content = {@Content(schema = @Schema())})})
    @PostMapping("public/v1/create")
    public ResponseEntity<String> createUser(@RequestBody UserDto userDto) {
        return new ResponseEntity<>(userService.createUser(userDto), HttpStatus.CREATED);
    }

    @Operation(description = "Get User by id",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(),
            responses = @io.swagger.v3.oas.annotations.responses.ApiResponse
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200",
                    content = {@Content(schema = @Schema(implementation = Long.class), mediaType = "application/json")}),
            @ApiResponse(responseCode = "401", content = {@Content(schema = @Schema(), mediaType = "application/json")}),
            @ApiResponse(responseCode = "500", content = {@Content(schema = @Schema())})})
    @GetMapping("private/v1/{userId}")
    @PreAuthorize("@apiSecurity.hasAdminRole()")
    public ResponseEntity<UserDto> getUser(@PathVariable Long userId) {
        return ResponseEntity.ok(userService.getUser(userId));
    }

    @Operation(description = "Get all user by filter",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(),
            responses = @io.swagger.v3.oas.annotations.responses.ApiResponse
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "401", content = {@Content(schema = @Schema(), mediaType = "application/json")}),
            @ApiResponse(responseCode = "500", content = {@Content(schema = @Schema())})})
    @PutMapping("private/v1/{userId}")
    public ResponseEntity<String> updateUser(@PathVariable Long userId, @RequestBody UserDto userDto) {
        return ResponseEntity.ok(userService.updateUser(userId, userDto));
    }


    @Operation(description = "Delete User By Id",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(),
            responses = @io.swagger.v3.oas.annotations.responses.ApiResponse
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200",
                    content = {@Content(schema = @Schema(implementation = String.class), mediaType = "application/json")}),
            @ApiResponse(responseCode = "401", content = {@Content(schema = @Schema(), mediaType = "application/json")}),
            @ApiResponse(responseCode = "500", content = {@Content(schema = @Schema())})})
    @DeleteMapping("private/v1/delete/{userId}")
    public ResponseEntity<String> deleteUser(@PathVariable Long userId) {
        return new ResponseEntity<>(userService.deleteUser(userId), HttpStatus.NO_CONTENT);
    }

    @ApiResponses({
            @ApiResponse(responseCode = "200",
                    content = {@Content(schema = @Schema(implementation = PageResponse.class), mediaType = "application/json")}),
            @ApiResponse(responseCode = "401", content = {@Content(schema = @Schema(), mediaType = "application/json")}),
            @ApiResponse(responseCode = "500", content = {@Content(schema = @Schema())})})
    @GetMapping("private/v1/users")
    @PreAuthorize("@apiSecurity.hasAdminRole()")
    public ResponseEntity<PageResponse<UserDto>> getUsers(@RequestParam(value = "page", defaultValue = "0") int page,
                                                          @RequestParam(value = "size", defaultValue = "20") int size,
                                                          @RequestParam(required = false, defaultValue = "email") String sortBy,
                                                          @RequestParam(required = false, defaultValue = "1") String order) throws BadRequestException {
        PageRequest pageable = filterBuilderService.getPageable(size, page, sortBy, order);
        return ResponseEntity.ok(userService.getUsers(pageable));
    }

}
