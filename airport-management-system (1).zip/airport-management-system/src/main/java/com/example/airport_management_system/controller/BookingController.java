package com.example.airport_management_system.controller;

import com.example.airport_management_system.dto.FeedbackDto;
import com.example.airport_management_system.dto.FlightBookingDto;
import com.example.airport_management_system.dto.PageResponse;
import com.example.airport_management_system.dto.TicketDto;
import com.example.airport_management_system.service.FlightBookingService;
import com.example.airport_management_system.util.FilterBuilderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.apache.coyote.BadRequestException;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.util.List;

@RestController
@RequestMapping("/api/booking")
@Tag(name = "Booking API")
public class BookingController {

    private final FlightBookingService flightBookingService;
    private final FilterBuilderService filterBuilderService;

    public BookingController(FlightBookingService flightBookingService, FilterBuilderService filterBuilderService) {
        this.flightBookingService = flightBookingService;
        this.filterBuilderService = filterBuilderService;
    }

    @Operation(summary = "Get all flight bookings")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved list of bookings"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @GetMapping("private/v1/all")
    @PreAuthorize("@apiSecurity.hasAdminRole()")
    public ResponseEntity<PageResponse<FlightBookingDto>> getAllBookings(@RequestParam(value = "page", defaultValue = "0") int page,
                                                                         @RequestParam(value = "size", defaultValue = "20") int size,
                                                                         @RequestParam(required = false, defaultValue = "bookingCode") String sortBy,
                                                                         @RequestParam(required = false, defaultValue = "1") String order) throws BadRequestException {
        PageRequest pageable = filterBuilderService.getPageable(size, page, sortBy, order);
        return ResponseEntity.ok(flightBookingService.getAllBookings(pageable));
    }

    @Operation(summary = "Get a flight booking by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved booking"),
            @ApiResponse(responseCode = "404", description = "Booking not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @GetMapping("private/v1/bookingId/{bookingId}")
    public ResponseEntity<FlightBookingDto> getBookingById(@PathVariable Long bookingId) {
        return ResponseEntity.ok(flightBookingService.getBookingById(bookingId));
    }

    @Operation(summary = "Get my bookings")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved booking"),
            @ApiResponse(responseCode = "404", description = "Booking not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @GetMapping("private/v1/mine")
    public ResponseEntity<List<FlightBookingDto>> getBookingById() {
        return ResponseEntity.ok(flightBookingService.getMyBookings());
    }

    @Operation(summary = "Get a flight booking by flightId")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved booking"),
            @ApiResponse(responseCode = "404", description = "Booking not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @GetMapping("private/v1/flightId/{flightId}")
    @PreAuthorize("@apiSecurity.hasAdminRole()")
    public ResponseEntity<FlightBookingDto> getBookingByFlightId(@PathVariable Long flightId) {
        return ResponseEntity.ok(flightBookingService.getBookingByFlightId(flightId));
    }

    @Operation(summary = "Flight booking")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully booked Ticket"),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PostMapping("private/v1/book")
    public ResponseEntity<TicketDto> bookTicket(@RequestBody @Valid FlightBookingDto flightBookingDto, @RequestParam Long flightId) {
        return new ResponseEntity<>(flightBookingService.bookTicket(flightBookingDto, flightId), HttpStatus.CREATED);
    }

    @PostMapping("private/v1/feedback")
    public ResponseEntity<FeedbackDto> submitFeedback(@RequestParam @NotNull Long bookingId,
                                                      @RequestParam(required = false) Long airportId,
                                                      @RequestParam(required = false) Long aircraftId,
                                                      @Valid @RequestBody FeedbackDto feedbackDto) {
        return ResponseEntity.ok(flightBookingService.submitFeedback(bookingId, feedbackDto,aircraftId,airportId));
    }

}
