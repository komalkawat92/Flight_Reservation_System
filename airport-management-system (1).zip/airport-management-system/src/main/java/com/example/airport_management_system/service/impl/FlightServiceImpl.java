package com.example.airport_management_system.service.impl;

import com.example.airport_management_system.advSearch.SearchCriteria;
import com.example.airport_management_system.advSearch.SearchDto;
import com.example.airport_management_system.dto.FilterDto;
import com.example.airport_management_system.dto.FlightDto;
import com.example.airport_management_system.dto.PageResponse;
import com.example.airport_management_system.entity.Aircraft;
import com.example.airport_management_system.entity.Airport;
import com.example.airport_management_system.entity.Flight;
import com.example.airport_management_system.repository.AircraftRepository;
import com.example.airport_management_system.repository.AirportRepository;
import com.example.airport_management_system.repository.FlightRepository;
import com.example.airport_management_system.service.FlightService;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class FlightServiceImpl implements FlightService {

    @Autowired
    private FlightRepository flightRepository;
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private AirportRepository airportRepository;
    @Autowired
    private AircraftRepository aircraftRepository;

    @Override
    public Flight addFlight(@Valid Flight flight) {
        return flightRepository.save(flight);
    }

    @Override
    public PageResponse<FlightDto> getAllFlights(Specification<Flight> specification, PageRequest pageable) {
        Page<Flight> flights = flightRepository.findAll(specification, pageable);
        List<FlightDto> flightDtos = modelMapper.map(flights.getContent(), new TypeToken<List<FlightDto>>() {}.getType());
        PageResponse<FlightDto> pageResponse = new PageResponse<>();
        pageResponse.setPageStats(flights,flightDtos);
        return pageResponse;
    }

    @Override
    public String deleteFlight(Long id) {
        return flightRepository.findByFlightId(id)
                .map(flight -> {
                    flightRepository.delete(flight);
                    return "Successfully deleted flight";
                })
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Flight Not Found"));
    }

    @Override
    public FlightDto getFlightById(Long flightId) {
        return flightRepository.findByFlightId(flightId)
                .map(flight -> modelMapper.map(flight,FlightDto.class))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Flight Not Found"));
    }

    @Override
    public FlightDto createFlight(FlightDto flightDto, Long departureAirportId, Long destinationAirportId, Long aircraftId) {
        Flight flight = modelMapper.map(flightDto, Flight.class);

        Airport departureAirport = airportRepository.findByAirportId(departureAirportId).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "Departure Airport Not Found"));

        Airport destinationAirport = airportRepository.findByAirportId(destinationAirportId).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "Destination Airport Not Found"));

        Aircraft aircraft = aircraftRepository.findByAircraftId(aircraftId).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "Aircraft Not Found"));

        flight.setAircraft(aircraft);
        flight.setDepartureAirport(departureAirport);
        flight.setDestinationAirport(destinationAirport);

        return modelMapper.map(flightRepository.save(flight),FlightDto.class);
    }

    @Override
    public FlightDto updateFlight(FlightDto flightDto, Long flightId, Long departureAirportId, Long destinationAirportId, Long aircraftId) {
        return flightRepository.findByFlightId(flightId)
                .map(flight -> {

                    modelMapper.getConfiguration().setSkipNullEnabled(true);

                    modelMapper.map(flightDto, flight);

                    if (departureAirportId != null) {
                        Airport departureAirport = airportRepository.findByAirportId(departureAirportId).orElseThrow(() ->
                                new ResponseStatusException(HttpStatus.NOT_FOUND, "Departure Airport Not Found"));
                        flight.setDepartureAirport(departureAirport);
                    }

                    if (destinationAirportId != null) {
                        Airport destinationAirport = airportRepository.findByAirportId(destinationAirportId).orElseThrow(() ->
                                new ResponseStatusException(HttpStatus.NOT_FOUND, "Departure Airport Not Found"));
                        flight.setDestinationAirport(destinationAirport);
                    }
                    if (aircraftId != null) {
                        Aircraft aircraft = aircraftRepository.findByAircraftId(aircraftId).orElseThrow(() ->
                                new ResponseStatusException(HttpStatus.NOT_FOUND, "Aircraft Not Found"));
                        flight.setAircraft(aircraft);
                    }

                    return modelMapper.map(flightRepository.save(flight), FlightDto.class);
                })
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Flight not found"));
    }

    @Override
    public SearchDto setSearchFilter(FilterDto filterDto) {
        if(ObjectUtils.isEmpty(filterDto)){
            return new SearchDto();
        }
        else{
            return withAllFilterOption(filterDto);
        }
    }

    private SearchDto withAllFilterOption(FilterDto filterDto) {
        List<SearchCriteria> searchCriteriaList = new ArrayList<>();

        if (!ObjectUtils.isEmpty(filterDto.getDepartureCity())) {
            SearchCriteria sc = SearchCriteria.builder()
                    .field("departureCity")
                    .filterOption("eq")
                    .value(Arrays.asList(filterDto.getDepartureCity()))
                    .operation("all")
                    .build();
            searchCriteriaList.add(sc);
        }

        if (!ObjectUtils.isEmpty(filterDto.getDestinationCity())) {
            SearchCriteria sc = SearchCriteria.builder()
                    .field("destinationCity")
                    .filterOption("eq")
                    .operation("all")
                    .value(Arrays.asList(filterDto.getDestinationCity()))
                    .build();
            searchCriteriaList.add(sc);
        }
        SearchDto searchDto= new SearchDto();
        searchDto.setSearchCriteriaList(searchCriteriaList);
        return searchDto;
    }
}