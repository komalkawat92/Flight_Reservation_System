package com.example.airport_management_system.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.airport_management_system.entity.Passenger;

public interface PassengerRepository extends JpaRepository<Passenger, Long> {}