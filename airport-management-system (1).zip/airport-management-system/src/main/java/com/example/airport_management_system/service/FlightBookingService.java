package com.example.airport_management_system.service;

import com.example.airport_management_system.dto.FeedbackDto;
import com.example.airport_management_system.dto.FlightBookingDto;
import com.example.airport_management_system.dto.PageResponse;
import com.example.airport_management_system.dto.TicketDto;
import org.springframework.data.domain.PageRequest;

import java.util.List;

public interface FlightBookingService {
    TicketDto bookTicket(FlightBookingDto flightBookingDto, Long flightId);

    PageResponse<FlightBookingDto> getAllBookings(PageRequest pageable);

    FlightBookingDto getBookingById(Long bookingId);

    FlightBookingDto getBookingByFlightId(Long flightId);

    List<FlightBookingDto> getMyBookings();

    FeedbackDto submitFeedback(Long bookingId, FeedbackDto feedbackDto, Long aircraftId, Long airportId);
}
