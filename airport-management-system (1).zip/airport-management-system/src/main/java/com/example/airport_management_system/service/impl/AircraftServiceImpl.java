package com.example.airport_management_system.service.impl;

import com.example.airport_management_system.dto.AircraftDto;
import com.example.airport_management_system.dto.PageResponse;
import com.example.airport_management_system.entity.Aircraft;
import com.example.airport_management_system.repository.AircraftRepository;
import com.example.airport_management_system.service.AircraftService;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;
import java.util.List;

@Service
public class AircraftServiceImpl implements AircraftService {

    @Autowired
    private AircraftRepository aircraftRepository;
    @Autowired
    private ModelMapper modelMapper;

    @Override
    public Aircraft addAircraft(@Valid Aircraft aircraft) {
        return aircraftRepository.save(aircraft);
    }

    @Override
    public PageResponse<AircraftDto> getAllAircrafts(PageRequest pageable) {
        Page<Aircraft> aircrafts = aircraftRepository.findAll(pageable);
        PageResponse pageResponse = new PageResponse<>();
        pageResponse.setPageStats(aircrafts, modelMapper
                .map(aircrafts.getContent(), new TypeToken<List<AircraftDto>>() {
                }.getType()));
        return pageResponse;
    }

    @Override
    public String deleteAircraft(Long id) {
        return aircraftRepository.findByAircraftId(id)
                .map(aircraft -> {
                    aircraftRepository.delete(aircraft);
                    return "Aircraft deleted";
                })
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Aircraft not found"));
    }

    @Override
    public AircraftDto getAircraftById(Long aircraftId) {
        return aircraftRepository.findByAircraftId(aircraftId)
                .map(aircraft -> modelMapper.map(aircraft, AircraftDto.class))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Aircraft Not Found"));
    }

    @Override
    public AircraftDto createOrUpdateAircraft(AircraftDto aircraftDto, Long aircraftId) {
        if (!ObjectUtils.isEmpty(aircraftId)) {
            return aircraftRepository.findByAircraftId(aircraftId)
                    .map(aircraft -> {
                        modelMapper.getConfiguration().setSkipNullEnabled(true);
                        modelMapper.map(aircraftDto, aircraft);
                        aircraftRepository.save(aircraft);
                        return modelMapper.map(aircraft, AircraftDto.class);
                    })
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Aircraft Not Found"));
        } else {
            Aircraft aircraft = modelMapper.map(aircraftDto, Aircraft.class);
            aircraftRepository.save(aircraft);
            return modelMapper.map(aircraft, AircraftDto.class);
        }
    }
}
