package com.example.airport_management_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirportManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
