package com.example.airport_management_system.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;


@Entity
@Data
public class Aircraft {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long aircraftId;
    private String manufacturer;
    private String model;
    private int capacity;
    private String registrationNumber;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER,mappedBy = "aircraft")
    private List<Feedback> feedbacks;
}