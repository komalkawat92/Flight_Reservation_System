package com.example.airport_management_system.advSearch;

import jakarta.persistence.criteria.From;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Root;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class QueryHelper {
    public From getFrom(SearchCriteria searchCriteria, Root root) {
        String columnName = searchCriteria.getField();
        if (root.getModel().getName().equals("Flight")) {
            return switch (columnName) {
                case "departureCity" -> departureAirportJoiner(root);
                case "destinationCity" -> destinationAirportJoiner(root);
                default -> root;
            };
        }
        log.info(root.toString());
        return root;
    }

    private Join<?, ?> departureAirportJoiner(Root root) {
        return root.join("departureAirport");
    }

    private Join<?, ?> destinationAirportJoiner(Root root) {
        return root.join("destinationAirport");
    }

}
