package com.example.airport_management_system.dto;

import com.example.airport_management_system.entity.Aircraft;
import com.example.airport_management_system.entity.Airport;
import com.example.airport_management_system.enumaration.FlightStatus;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FlightDto {

    @Schema(description = "Unique identifier of the flight", example = "2001",hidden = true)
    private Long flightId;

    @Schema(description = "Flight number", example = "UA123")
    private String flightNumber;

    @Schema(description = "Date of departure", example = "2024-08-01")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate departureDate;

    @Schema(description = "Date of arrival", example = "2024-08-01")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate arrivalDate;

    @Schema(description = "Time of departure", example = "15:30:00")
    @JsonFormat(pattern = "HH:mm:ss")
    private LocalTime departureTime;

    @Schema(description = "Time of arrival", example = "18:45:00")
    @JsonFormat(pattern = "HH:mm:ss")
    private LocalTime arrivalTime;

    @Schema(description = "Charge for the flight", example = "299.99")
    private double flightCharge;

    @Schema(description = "Status of the flight", example = "SCHEDULED", allowableValues = {"SCHEDULED", "DELAYED", "CANCELLED"})
    private FlightStatus status;

    @Schema(description = "Number of available seats", example = "50")
    private Long availableSeat;

    @Schema(description = "Departure airport details",hidden = true)
    private AirportDto departureAirport;

    @Schema(description = "Destination airport details",hidden = true)
    private AirportDto destinationAirport;

    @Schema(description = "Aircraft details",hidden = true)
    private AircraftDto aircraft;
}
