package com.example.airport_management_system.service;

import com.example.airport_management_system.dto.AirportDto;
import com.example.airport_management_system.dto.PageResponse;
import com.example.airport_management_system.entity.Airport;
import org.springframework.data.domain.PageRequest;

import javax.validation.Valid;
import java.util.List;

public interface AirportService {
    PageResponse<AirportDto> getAllAirports(PageRequest pageable);
    String deleteAirport(Long id);
    AirportDto getAirportById(Long id);
    AirportDto createOrUpdateAirport(AirportDto airport, Long airportId);
}
