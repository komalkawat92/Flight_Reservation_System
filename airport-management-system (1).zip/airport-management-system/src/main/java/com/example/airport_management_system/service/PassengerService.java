package com.example.airport_management_system.service;

import javax.validation.Valid;

import com.example.airport_management_system.entity.Passenger;

import java.util.List;

public interface PassengerService {
    
    Passenger addPassenger(@Valid Passenger passenger);

    List<Passenger> getAllPassengers();
}