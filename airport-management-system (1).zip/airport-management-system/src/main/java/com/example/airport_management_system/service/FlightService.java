
package com.example.airport_management_system.service;

import javax.validation.Valid;

import com.example.airport_management_system.advSearch.SearchDto;
import com.example.airport_management_system.dto.FilterDto;
import com.example.airport_management_system.dto.FlightDto;
import com.example.airport_management_system.dto.PageResponse;
import com.example.airport_management_system.entity.Flight;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;

public interface FlightService {
    
    Flight addFlight(@Valid Flight flight);

    PageResponse<FlightDto> getAllFlights(Specification<Flight> build, PageRequest pageable);

    String deleteFlight(Long id);

    FlightDto getFlightById(Long flightId);

    FlightDto createFlight(FlightDto flightDto, Long departureAirportId, Long destinationAirportId, Long aircraftId);

    FlightDto updateFlight(FlightDto flightDto, Long flightId, Long departureAirportId, Long destinationAirportId, Long aircraftId);

    SearchDto setSearchFilter(FilterDto filterDto);

}