package com.example.airport_management_system.service.impl;

import com.example.airport_management_system.entity.Passenger;
import com.example.airport_management_system.repository.PassengerRepository;
import com.example.airport_management_system.service.PassengerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.util.List;

@Service
public class PassengerServiceImpl implements PassengerService {
    
    @Autowired
    private PassengerRepository passengerRepository;

    @Override
    public Passenger addPassenger(@Valid Passenger passenger) {
        return passengerRepository.save(passenger);
    }

    @Override
    public List<Passenger> getAllPassengers() {
        return passengerRepository.findAll();
    }
}