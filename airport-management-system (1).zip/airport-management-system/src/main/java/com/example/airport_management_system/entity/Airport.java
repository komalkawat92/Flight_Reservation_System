package com.example.airport_management_system.entity;

import com.example.airport_management_system.dto.FeedbackDto;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Airport {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long airportId;
    private String name;
    private String city;
    private String country;
    private Double latitude;
    private Double longitude;
    private Integer terminalCount;

    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER,mappedBy = "airport")
    private List<Feedback> feedbacks;
}
