### swagger 

```angular2html
http://localhost:8080/swagger-ui/index.html#/
```