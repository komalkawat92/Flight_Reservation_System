package com.example.airport_management_system.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import lombok.Data;

@Data
public class PassengerDto {

    @Schema(hidden = true)
    private Long passengerId;

    @Schema(example = "John")
    private String firstName;

    @Schema(example = "Doe")
    private String lastName;

    @Schema(example = "+1234567890")
    private String phoneNumber;

    @Schema(example = "A1234567")
    private String passport;

    @Schema(example = "jdoe@example.com")
    @Email(message = "Enter valid email address")
    private String email;

    @Schema(example = "123 Main St")
    private String address;
}
