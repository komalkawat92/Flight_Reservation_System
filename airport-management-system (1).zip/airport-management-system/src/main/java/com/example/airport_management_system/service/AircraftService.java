package com.example.airport_management_system.service;

import com.example.airport_management_system.dto.AircraftDto;
import com.example.airport_management_system.dto.PageResponse;
import com.example.airport_management_system.entity.Aircraft;
import org.springframework.data.domain.PageRequest;

import javax.validation.Valid;

public interface AircraftService {
    Aircraft addAircraft(@Valid Aircraft aircraft);
    PageResponse<AircraftDto> getAllAircrafts(PageRequest pageable);
    String deleteAircraft(Long id);

    AircraftDto getAircraftById(Long aircraftId);

    AircraftDto createOrUpdateAircraft(AircraftDto aircraft, Long aircraftId);
}
