package com.example.airport_management_system.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserProfileDto {

    @Schema(hidden = true)
    private Long id;

    @Schema(example = "user")
    private String role;
}
