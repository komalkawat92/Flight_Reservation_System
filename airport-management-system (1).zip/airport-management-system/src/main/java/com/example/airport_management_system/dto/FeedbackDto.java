package com.example.airport_management_system.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Range;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FeedbackDto {

    @Schema(hidden = true)
    private Long feedbackId;

    @Schema(example = "4")
    @Range(min = 1, max = 5, message = "Feedback should be in between 1 to 5")
    private Integer rating;

    @Schema(example = "good")
    private String comments;

    @JsonFormat(pattern = "dd-MM-yyyy:HH:mm:ss")
    @Schema(hidden = true)
    private LocalDateTime submittedOn;

    @Schema(hidden = true)
    private UserDto user;
}
