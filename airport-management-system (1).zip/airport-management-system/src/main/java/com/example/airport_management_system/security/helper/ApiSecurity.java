package com.example.airport_management_system.security.helper;

import com.example.airport_management_system.enumaration.Roles;
import com.example.airport_management_system.security.context.RequestContext;
import org.springframework.stereotype.Component;

@Component
public class ApiSecurity {

    private final RequestContext requestContext;

    public ApiSecurity(RequestContext requestContext) {
        this.requestContext = requestContext;
    }

    public boolean hasAdminRole() {
        return requestContext.getRoles()
                .stream()
                .anyMatch(s -> s.contains(Roles.ADMIN.getRole()));
    }

    public boolean hasUserRole() {
        return requestContext.getRoles()
                .stream()
                .anyMatch(s -> s.contains(Roles.USER.getRole()));
    }
}
