package com.example.airport_management_system.enumaration;


public enum FlightStatus {
    SCHEDULED("SCHEDULED"),
    DELAYED("DELAYED"),
    CANCELLED("CANCELLED");

    private final  String status;

    FlightStatus(String status) {
        this.status = status;
    }

    private  String getStatus(){
        return status;
    }
}
