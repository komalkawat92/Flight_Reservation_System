package com.example.airport_management_system.controller;
import com.example.airport_management_system.dto.UserLoginRequestDto;
import com.example.airport_management_system.service.AuthService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@Tag(name = "Auth API")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("public/v1/login")
    @Operation(description = "Login User",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(),
            responses = @io.swagger.v3.oas.annotations.responses.ApiResponse
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200",
                    content = { @Content(schema = @Schema(implementation = UserLoginRequestDto.class), mediaType = "application/json") }),
            @ApiResponse(responseCode = "401", content = { @Content(schema = @Schema(), mediaType = "application/json") }),
            @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
    private ResponseEntity<String> login(@RequestBody UserLoginRequestDto userLoginRequestDto){
        return ResponseEntity.ok(authService.loginUser(userLoginRequestDto));
    }
}