package com.example.airport_management_system.security.contstant;

public class SecurityConstants {
    public static final String JWT_HEADER = "Authorization";
    public static final String CONTENT_TOKEN = "content-token";
    public static final String SESSION_ID = "sessionid";
    public static final String ROLES_CLAIM = "roles";
}