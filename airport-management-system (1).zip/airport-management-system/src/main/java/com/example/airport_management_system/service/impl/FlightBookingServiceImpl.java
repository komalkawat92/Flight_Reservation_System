package com.example.airport_management_system.service.impl;

import com.example.airport_management_system.dto.*;
import com.example.airport_management_system.entity.Aircraft;
import com.example.airport_management_system.entity.Airport;
import com.example.airport_management_system.entity.Feedback;
import com.example.airport_management_system.entity.FlightBooking;
import com.example.airport_management_system.repository.*;
import com.example.airport_management_system.security.context.RequestContext;
import com.example.airport_management_system.service.FlightBookingService;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class FlightBookingServiceImpl implements FlightBookingService {
    private final FlightRepository flightRepository;
    private final ModelMapper modelMapper;
    private final UserRepository userRepository;
    private final RequestContext requestContext;
    private final FlightBookingRepository flightBookingRepository;
    private final FeedbackRepository feedbackRepository;
    private final AircraftRepository aircraftRepository;
    private final AirportRepository airportRepository;

    public FlightBookingServiceImpl(FlightRepository flightRepository, ModelMapper modelMapper, UserRepository userRepository, RequestContext requestContext, FlightBookingRepository flightBookingRepository, FeedbackRepository feedbackRepository, AircraftRepository aircraftRepository, AirportRepository airportRepository) {
        this.flightRepository = flightRepository;
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;
        this.requestContext = requestContext;
        this.flightBookingRepository = flightBookingRepository;
        this.feedbackRepository = feedbackRepository;
        this.aircraftRepository = aircraftRepository;
        this.airportRepository = airportRepository;
    }

    @Override
    public TicketDto bookTicket(FlightBookingDto flightBookingDto, Long flightId) {
        return flightRepository.findById(flightId).map(flight -> {

                    if (flight.getAvailableSeat() < flightBookingDto.getPassengers().size())
                        throw new ResponseStatusException(HttpStatus.CONFLICT, "Seats are not available");

                    FlightBooking flightBooking = modelMapper.map(flightBookingDto, FlightBooking.class);
                    flightBooking.setFlight(flight);

                    userRepository.findByUserId(requestContext.getUserId())
                            .ifPresent(flightBooking::setUser);

                    flightBooking.setBookingDate(LocalDateTime.now());

                    flightBooking.getPassengers().forEach(passenger -> passenger.setFlightBooking(flightBooking));

                    FlightBooking booking = flightBookingRepository.save(flightBooking);

                    flight.setAvailableSeat(flight.getAvailableSeat() - flightBookingDto.getPassengers().size());

                    flight = flightRepository.save(flight);

                    return TicketDto.builder()
                            .bookingTime(LocalDateTime.now())
                            .ticketId(booking.getBookingId())
                            .price(flight.getFlightCharge() * flightBookingDto.getPassengers().size())
                            .flight(modelMapper.map(flight, FlightDto.class))
                            .passengers(flightBookingDto.getPassengers())
                            .build();
                })
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.CONFLICT, "No flight found"));
    }

    @Override
    public PageResponse<FlightBookingDto> getAllBookings(PageRequest pageable) {
        Page<FlightBooking> bookings = flightBookingRepository.findAll(pageable);
        List<FlightBookingDto> flightBookingDto = modelMapper.map(bookings.getContent(), new TypeToken<List<FlightBookingDto>>() {
        }.getType());
        PageResponse pageResponse = new PageResponse<>();
        pageResponse.setPageStats(bookings, flightBookingDto);
        return pageResponse;
    }

    @Override
    public FlightBookingDto getBookingById(Long bookingId) {
        return flightBookingRepository.findByBookingId(bookingId)
                .map(flightBooking -> modelMapper.map(flightBooking, FlightBookingDto.class))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "No flight found"));
    }

    @Override
    public FlightBookingDto getBookingByFlightId(Long flightId) {
        return flightBookingRepository.findByFlight_FlightId(flightId)
                .map(flightBooking -> modelMapper.map(flightBooking, FlightBookingDto.class))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "No flight found"));
    }

    @Override
    public List<FlightBookingDto> getMyBookings() {
        return modelMapper.map(flightBookingRepository.findByUser_UserId(requestContext.getUserId()),
                new TypeToken<List<FlightBookingDto>>() {
                }.getType());
    }

    @Override
    public FeedbackDto submitFeedback(Long bookingId, FeedbackDto feedbackDto, Long aircraftId, Long airportId) {
        return flightBookingRepository.findByBookingId(bookingId)
                .map(flightBooking -> {
                    Feedback feedback = modelMapper.map(feedbackDto, Feedback.class);
                    feedback.setSubmittedOn(LocalDateTime.now());
                    feedback.setUser(userRepository.findByUserId(requestContext.getUserId()).get());

                    if (aircraftId != null) {
                        Aircraft aircraft = aircraftRepository.findByAircraftId(aircraftId)
                                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "No Aircraft found"));
                        feedback.setAircraft(aircraft);
                    }

                    if (airportId != null) {
                        Airport airport = airportRepository.findByAirportId(airportId).orElseThrow(() ->
                                new ResponseStatusException(HttpStatus.NOT_FOUND, "No Airport found"));
                        feedback.setAirport(airport);
                    }
                    FeedbackDto feedbackDto1 = modelMapper.map(feedbackRepository.save(feedback), FeedbackDto.class);
                    feedbackDto1.getUser().setPassword(null);
                    feedbackDto1.getUser().setUserProfiles(null);
                    return feedbackDto1;
                })
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "No Booking found"));
    }
}
