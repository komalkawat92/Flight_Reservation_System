package com.example.airport_management_system.service.impl;

import com.example.airport_management_system.dto.AirportDto;
import com.example.airport_management_system.dto.PageResponse;
import com.example.airport_management_system.entity.Airport;
import com.example.airport_management_system.repository.AirportRepository;
import com.example.airport_management_system.service.AirportService;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;
import java.util.List;

@Service
public class AirportServiceImpl implements AirportService {

    private final AirportRepository airportRepository;
    private final ModelMapper modelMapper;

    public AirportServiceImpl(AirportRepository airportRepository, ModelMapper modelMapper) {
        this.airportRepository = airportRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public PageResponse<AirportDto> getAllAirports(PageRequest pageable) {
        Page<Airport> airports = airportRepository.findAll(pageable);
        PageResponse pageResponse = new PageResponse<>();
        pageResponse.setPageStats(airports, modelMapper
                .map(airports.getContent(), new TypeToken<List<AirportDto>>() {
                }.getType()));
        return pageResponse;
    }

    @Override
    public String deleteAirport(Long id) {
        return airportRepository.findByAirportId(id)
                .map(airport -> {
                    airportRepository.delete(airport);
                    return "Airport deleted";
                })
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Airport not found"));
    }

    @Override
    public AirportDto getAirportById(Long id) {
        return airportRepository.findByAirportId(id)
                .map(airport -> modelMapper.map(airport, AirportDto.class))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Airport Not Found"));
    }

    @Override
    public AirportDto createOrUpdateAirport(AirportDto airportDto, Long airportId) {
        if (!ObjectUtils.isEmpty(airportId)) {
            return airportRepository.findByAirportId(airportId)
                    .map(airport -> {
                        modelMapper.getConfiguration().setSkipNullEnabled(true);
                        modelMapper.map(airportDto, airport);
                        airportRepository.save(airport);
                        return modelMapper.map(airport, AirportDto.class);
                    })
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Airport Not Found"));
        } else {
            Airport airport = modelMapper.map(airportDto, Airport.class);
            airportRepository.save(airport);
            return modelMapper.map(airport, AirportDto.class);
        }
    }
}
