package com.example.airport_management_system.advSearch;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SearchCriteria {

    private String field;
    private List<String> value;
    private String operation;
    private String filterOption;

    public SearchCriteria(String field, String operation, List<String>  value){
        super();
        this.field = field;
        this.operation = operation;
        this.value = value;
    }
}
