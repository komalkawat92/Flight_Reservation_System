
package com.example.airport_management_system.service;


import com.example.airport_management_system.dto.PageResponse;
import com.example.airport_management_system.dto.UserDto;
import com.example.airport_management_system.entity.User;
import org.springframework.data.domain.PageRequest;

public interface UserService {
    String createUser(UserDto userDto);

    UserDto getUser(Long userId);

    String deleteUser(Long userId);

    String updateUser(Long userId, UserDto userDto);

    PageResponse<UserDto> getUsers(PageRequest pageable);
}