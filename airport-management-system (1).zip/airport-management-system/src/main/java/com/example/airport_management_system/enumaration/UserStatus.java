package com.example.airport_management_system.enumaration;

public enum UserStatus {
    ACTIVE("active"),
    WITHDRAWN("withdrawn"),
    DELETED("deleted");

    private final String status;

    UserStatus(String status) {
        this.status = status;
    }
    public String getStatus() {
        return status;
    }
}
