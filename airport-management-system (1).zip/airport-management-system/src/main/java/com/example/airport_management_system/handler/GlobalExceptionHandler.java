package com.example.airport_management_system.handler;

import com.example.airport_management_system.dto.ErrorResponseDTO;
import com.example.airport_management_system.security.context.RequestContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ResponseStatusException;

import java.nio.file.AccessDeniedException;
import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
@Slf4j
@Order(Ordered.HIGHEST_PRECEDENCE)
public class GlobalExceptionHandler{

    private final RequestContext requestContext;

    public GlobalExceptionHandler(RequestContext requestContext) {
        this.requestContext = requestContext;
    }

    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<ErrorResponseDTO> getResponseStatusException(ResponseStatusException exception) {
        log.error("getResponseStatusException {}", exception.getMessage());
        return new ResponseEntity<>(ErrorResponseDTO.builder()
                .status(exception.getStatusCode().value())
                .message(exception.getReason())
                .build(),exception.getStatusCode());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(
            MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponseDTO getException(Exception exception) {
        log.error("getException {}", exception.getMessage(), exception);
        return ErrorResponseDTO.builder()
                .status(HttpStatus.BAD_REQUEST.value())
                .message(exception.getMessage())
                .build();
    }

    @ExceptionHandler(BadCredentialsException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ErrorResponseDTO getBadCredentialsException(BadCredentialsException exception) {
        log.error("getBadCredentialsException {}", exception.getMessage());
        return ErrorResponseDTO.builder()
                .status(HttpStatus.FORBIDDEN.value())
                .message(exception.getMessage())
                .build();
    }


    @ExceptionHandler(AccessDeniedException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ErrorResponseDTO getAccessDeniedException(AccessDeniedException exception) {
        log.error("getAccessDeniedException {}", exception.getMessage());
        return ErrorResponseDTO.builder()
                .status(HttpStatus.FORBIDDEN.value())
                .message("You are not allowed to perform this operation")
                .build();
    }

}