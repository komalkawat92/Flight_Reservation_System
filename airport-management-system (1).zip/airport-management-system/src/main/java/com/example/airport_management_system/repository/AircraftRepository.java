package com.example.airport_management_system.repository;


import org.modelmapper.ModelMapper;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.airport_management_system.entity.Aircraft;

import java.util.Optional;

public interface AircraftRepository extends JpaRepository<Aircraft, Long> {
    Optional<Aircraft> findByAircraftId(Long aircraftId);
}