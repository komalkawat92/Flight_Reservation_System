package com.example.airport_management_system.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FlightBookingDto {

    @Schema(hidden = true)
    private Long bookingId;

    @Schema(hidden = true)
    private FlightDto flight;

    @Schema(example = "abc")
    private String bookingCode;

    @Schema(hidden = true)
    @JsonFormat(pattern = "dd-MM-yyyy:HH:mm:ss")
    private LocalDateTime bookingDate;

    @Valid
    private List<PassengerDto> passengers;
}
