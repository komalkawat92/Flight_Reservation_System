package com.example.airport_management_system.controller;

import com.example.airport_management_system.dto.AirportDto;
import com.example.airport_management_system.dto.PageResponse;
import com.example.airport_management_system.service.AirportService;
import com.example.airport_management_system.util.FilterBuilderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.coyote.BadRequestException;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/airports")
@Tag(name = "Airport API")
public class AirportController {

    private final AirportService airportService;
    private final FilterBuilderService filterBuilderService;

    public AirportController(AirportService airportService, FilterBuilderService filterBuilderService) {
        this.airportService = airportService;
        this.filterBuilderService = filterBuilderService;
    }

    @Operation(summary = "Get all airports")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved list of airports"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @GetMapping("public/v1/all")
    public ResponseEntity<PageResponse<AirportDto>> getAllAirports(@RequestParam(value = "page", defaultValue = "0") int page,
                                                                   @RequestParam(value = "size", defaultValue = "20") int size,
                                                                   @RequestParam(required = false, defaultValue = "city") String sortBy,
                                                                   @RequestParam(required = false, defaultValue = "1") String order) throws BadRequestException {
        PageRequest pageable = filterBuilderService.getPageable(size, page, sortBy, order);
        return ResponseEntity.ok(airportService.getAllAirports(pageable));
    }

    @Operation(summary = "Get an airport by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved airport"),
            @ApiResponse(responseCode = "404", description = "Airport not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @GetMapping("public/v1/get/{airportId}")
    public ResponseEntity<AirportDto> getAirportById(@PathVariable Long airportId) {
        return ResponseEntity.ok(airportService.getAirportById(airportId));
    }

    @Operation(summary = "Create or update an airport")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created or updated airport"),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PostMapping("private/v1/create-update")
    @PreAuthorize("@apiSecurity.hasAdminRole()")
    public ResponseEntity<AirportDto> createOrUpdateAirport(@RequestBody AirportDto airport,
                                                            @RequestParam(required = false) Long airportId) {
        return ResponseEntity.ok(airportService.createOrUpdateAirport(airport, airportId));
    }

    @Operation(summary = "Delete an airport by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Successfully deleted airport"),
            @ApiResponse(responseCode = "404", description = "Airport not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @DeleteMapping("private/v1/delete/{airportId}")
    @PreAuthorize("@apiSecurity.hasAdminRole()")
    public ResponseEntity<String> deleteAirport(@PathVariable Long airportId) {
        return ResponseEntity.ok(airportService.deleteAirport(airportId));
    }
}
