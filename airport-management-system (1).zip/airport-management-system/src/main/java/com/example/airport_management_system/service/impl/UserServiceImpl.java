package com.example.airport_management_system.service.impl;

import com.example.airport_management_system.dto.PageResponse;
import com.example.airport_management_system.dto.UserDto;
import com.example.airport_management_system.entity.User;
import com.example.airport_management_system.entity.UserProfile;
import com.example.airport_management_system.enumaration.Roles;
import com.example.airport_management_system.repository.UserProfileRepository;
import com.example.airport_management_system.repository.UserRepository;
import com.example.airport_management_system.security.context.RequestContext;
import com.example.airport_management_system.service.UserService;
import com.example.airport_management_system.util.Common;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.server.ResponseStatusException;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Service
@Slf4j
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final ModelMapper modelMapper;
    private final PasswordEncoder passwordEncoder;
    private final RequestContext requestContext;
    private final UserProfileRepository userProfileRepository;

    public UserServiceImpl(UserRepository userRepository, ModelMapper modelMapper, PasswordEncoder passwordEncoder, RequestContext requestContext, UserProfileRepository userProfileRepository) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
        this.passwordEncoder = passwordEncoder;
        this.requestContext = requestContext;
        this.userProfileRepository = userProfileRepository;
    }

    @Override
    @Transactional
    public String createUser(UserDto userDto) {
        log.info("UserServiceImpl :: createUser");
        validateUser(userDto);

        User user = modelMapper.map(userDto, User.class);
        user.setPassword(passwordEncoder.encode(userDto.getPassword()));
        List<UserProfile> userProfiles = user.getUserProfiles();
        if (ObjectUtils.isEmpty(userProfiles) && ObjectUtils.isEmpty(userProfiles.get(0))) {
            UserProfile userProfile = new UserProfile();
            userProfile.setRole(Roles.USER.getRole());
            userProfiles =  Arrays.asList(userProfile);
        }

        userProfiles.forEach(userProfile -> userProfile.setUser(user));

        user.setUserProfiles(userProfiles);

        user.setCreatedAt(new Date());
        user.setUpdatedAt(new Date());

        userRepository.save(user);
        log.info("UserServiceImpl :: createUser :: user successfully created");
        return "User Successfully created";
    }

    @Override
    public UserDto getUser(Long userId) {
        return userRepository.findByUserId(userId)
                .map(user -> {
                    UserDto userDto = modelMapper.map(user, UserDto.class);
                    userDto.setPassword(null);
                    return userDto;
                })
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));
    }

    @Override
    public String deleteUser(Long userId) {
        return userRepository.findByUserId(userId)
                .map(user -> {
                    userRepository.delete(user);
                    log.info("UserServiceImpl :: deleteUser :: user successfully deleted");
                    return "User Successfully deleted";
                })
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));
    }

    @Override
    public String updateUser(Long userId, UserDto userDto) {
        return userRepository.findByUserId(userId).map(user -> {

            if (!requestContext.getRoles().contains("ROLE_" + Roles.ADMIN.getRole()) &&
                    !user.getEmail().equalsIgnoreCase(requestContext.getPreferredUserName()))
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You are not allowed to perform this operation");
            modelMapper.getConfiguration().setSkipNullEnabled(true);
            modelMapper.map(userDto, user);
            user.setUpdatedAt(new Date());
            userRepository.save(user);
            return "User updated successfully";
        }).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User Not Found"));
    }

    @Override
    public PageResponse<UserDto> getUsers(PageRequest pageable) {
        Page<User> users = userRepository.findAll(pageable);
        List<User> userList = users.getContent().stream().peek(user -> {
            user.setPassword(null);
            user.setUserProfiles(null);
        }).toList();
        List<UserDto> userDtoList = modelMapper.map(userList, new TypeToken<List<UserDto>>() {
        }.getType());
        PageResponse pageResponse = new PageResponse();
        pageResponse.setPageStats(users,userDtoList);
       return pageResponse;
    }

    private void validateUser(UserDto userDto) {
        if (Boolean.FALSE.equals(Common.isValidEmail(userDto.getEmail())))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Please enter a valid email address");

        if (Boolean.FALSE.equals(Common.isValidPassword(userDto.getPassword())))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Please enter a valid password");

        userRepository.findByEmail(userDto.getEmail())
                .ifPresent(user -> {
                    throw new ResponseStatusException(HttpStatus.CONFLICT, "User is already exist");
                });
    }
}
