package com.example.airport_management_system.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.airport_management_system.entity.Flight;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Optional;

public interface FlightRepository extends JpaRepository<Flight, Long>, JpaSpecificationExecutor<Flight> {
    Optional<Flight> findByFlightId(Long id);
}