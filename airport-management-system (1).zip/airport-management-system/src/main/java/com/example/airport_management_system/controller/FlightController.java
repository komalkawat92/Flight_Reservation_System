package com.example.airport_management_system.controller;

import com.example.airport_management_system.advSearch.SpecificationBuilder;
import com.example.airport_management_system.dto.FilterDto;
import com.example.airport_management_system.dto.FlightDto;
import com.example.airport_management_system.dto.PageResponse;
import com.example.airport_management_system.service.FlightService;
import com.example.airport_management_system.util.FilterBuilderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/flights")
@Tag(name = "Flight API")
public class FlightController {

    @Autowired
    private FlightService flightService;
    @Autowired
    private FilterBuilderService filterBuilderService;

    @Operation(summary = "Get all flights")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved list of flights"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PostMapping("public/v1/all")
    public ResponseEntity<PageResponse<FlightDto>> getAllFlights(@RequestParam(value = "page", defaultValue = "0") int page,
                                                                 @RequestParam(value = "size", defaultValue = "20") int size,
                                                                 @RequestParam(required = false, defaultValue = "flightNumber") String sortBy,
                                                                 @RequestParam(required = false, defaultValue = "1") String order,
                                                                 @RequestBody(required = false) FilterDto filterDto) throws BadRequestException {
        if(ObjectUtils.isEmpty(filterDto))
            filterDto =new FilterDto();

        SpecificationBuilder builder = new SpecificationBuilder();

        flightService.setSearchFilter(filterDto)
                .getSearchCriteriaList()
                .forEach(searchCriteria -> {
                    if(searchCriteria!= null)
                        builder.with(searchCriteria);
                });
        PageRequest pageable = filterBuilderService.getPageable(size, page, sortBy, order);

        return ResponseEntity.ok(flightService.getAllFlights(builder.build(),pageable));
    }

    @Operation(summary = "Get a flight by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved flight"),
            @ApiResponse(responseCode = "404", description = "Flight not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @GetMapping("public/v1/{flightId}")
    public ResponseEntity<FlightDto> getFlightById(@PathVariable Long flightId) {
      return ResponseEntity.ok(flightService.getFlightById(flightId));
    }

    @Operation(summary = "update a flight")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully updated flight"),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PutMapping("private/v1/update")
    @PreAuthorize("@apiSecurity.hasAdminRole()")
    public ResponseEntity<FlightDto> updateFlight(@RequestBody FlightDto flightDto,
                                                  @RequestParam Long flightId,
                                                  @RequestParam(required = false) Long departureAirportId,
                                                  @RequestParam(required = false) Long destinationAirportId,
                                                  @RequestParam(required = false) Long aircraftId) {
        return new ResponseEntity<>(flightService.updateFlight(flightDto,
                flightId,
                departureAirportId,
                destinationAirportId,
                aircraftId), HttpStatus.OK);
    }

    @Operation(summary = "create a flight")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created  flight"),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PostMapping("private/v1/add")
    @PreAuthorize("@apiSecurity.hasAdminRole()")
    public ResponseEntity<FlightDto> createFlight(@RequestBody FlightDto flightDto,
                                                  @RequestParam Long departureAirportId,
                                                  @RequestParam Long destinationAirportId,
                                                  @RequestParam Long aircraftId) {
        return new ResponseEntity<>(flightService.createFlight(flightDto,
                departureAirportId,
                destinationAirportId,
                aircraftId), HttpStatus.CREATED);
    }

    @Operation(summary = "Delete a flight by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Successfully deleted flight"),
            @ApiResponse(responseCode = "404", description = "Flight not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @DeleteMapping("private/v1/delete/{flightId}")
    @PreAuthorize("@apiSecurity.hasAdminRole()")
    public ResponseEntity<String> deleteFlight(@PathVariable Long flightId) {
      return ResponseEntity.ok(flightService.deleteFlight(flightId));
    }
}