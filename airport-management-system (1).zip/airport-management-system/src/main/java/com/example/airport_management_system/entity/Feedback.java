package com.example.airport_management_system.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@Entity
public class Feedback {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long feedbackId;
    private Integer rating; // E.g., 1 to 5
    private String comments;
    private LocalDateTime submittedOn;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "airport_id")
    @JsonIgnore
    private Airport airport;

    @ManyToOne
    @JoinColumn(name = "aircraft_id")
    @JsonIgnore
    private Aircraft aircraft;
}