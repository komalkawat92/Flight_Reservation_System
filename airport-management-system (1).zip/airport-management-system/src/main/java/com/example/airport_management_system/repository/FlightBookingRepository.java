package com.example.airport_management_system.repository;

import com.example.airport_management_system.entity.FlightBooking;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface FlightBookingRepository extends JpaRepository<FlightBooking, Long> {

    Optional<FlightBooking> findByBookingId(Long bookingId);

    Optional<FlightBooking> findByFlight_FlightId(Long bookingId);

    List<FlightBooking> findByUser_UserId(Long userId);

}
