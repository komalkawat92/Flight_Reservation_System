package com.example.airport_management_system.advSearch;



import java.util.ArrayList;
import java.util.List;

public class SpecificationBuilder {

    private final List<SearchCriteria> params;

    public SpecificationBuilder(){
        this.params = new ArrayList<>();
    }

    public final SpecificationBuilder with(String key, String operation, List<String>  value){
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }

    public final SpecificationBuilder with(SearchCriteria searchCriteria){
        params.add(searchCriteria);
        return this;
    }

    public org.springframework.data.jpa.domain.Specification build(){
        if(params.size() == 0){
            return null;
        }

        org.springframework.data.jpa.domain.Specification result = new Specification(params.get(0));
        for (int idx = 1; idx < params.size(); idx++){
            SearchCriteria criteria = params.get(idx);
            result = SearchOperation.getDataOption(criteria.getFilterOption()) == SearchOperation.ALL
                    ? org.springframework.data.jpa.domain.Specification.where(result).and(new Specification(criteria))
                    : org.springframework.data.jpa.domain.Specification.where(result).or(new Specification(criteria));
        }
        return result;
    }
}
