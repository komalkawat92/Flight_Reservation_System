package com.example.airport_management_system.service;


import com.example.airport_management_system.dto.UserLoginRequestDto;

public interface AuthService {

    String loginUser(UserLoginRequestDto userLoginRequestDto);

}
