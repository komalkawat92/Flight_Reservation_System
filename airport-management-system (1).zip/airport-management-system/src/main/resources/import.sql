INSERT INTO aircraft (aircraft_id, manufacturer, model, no_of_seats) VALUES (1, 'Boeing', '747', 416);
INSERT INTO aircraft (aircraft_id, manufacturer, model, no_of_seats) VALUES (2, 'Airbus', 'A320', 180);
