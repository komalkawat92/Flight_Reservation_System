package com.example.airport_management_system.util;

import org.apache.coyote.BadRequestException;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class FilterBuilderService {

    private static final int DEFAULT_SIZE_PAGE = 20;

    /**
     * Get request pageable. Page Request Builder. custom pageable
     *
     * @param size  the number of items to collect
     * @param page  page number
     * @param order search order filter (eg: field|ASC)
     * @return PageRequest
     */
    public PageRequest getPageable(int size, int page, String sortBy, String order) throws BadRequestException {

        int pageSize = (size <= 0) ? DEFAULT_SIZE_PAGE : size;
        int currentPage = (page <= 0) ? 1 : page;

        try {
            if (order.equalsIgnoreCase("1")) {
                return PageRequest.of((currentPage - 1), pageSize, Sort.by(Sort.Direction.ASC, sortBy));
            } else if (order.equalsIgnoreCase("0")) {
                return PageRequest.of((currentPage - 1), pageSize, Sort.by(Sort.Direction.DESC, sortBy));
            } else {
                throw new IllegalArgumentException("Please enter the correct order!!");
            }
        } catch (Exception ex) {
            throw new BadRequestException("Cannot create condition filter " + ex.getMessage());
        }
    }
}