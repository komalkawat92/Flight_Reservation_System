package com.example.airport_management_system.enumaration;

public enum Roles {
    USER("user"),
    ADMIN("admin");

    private final String role;
    private Roles(String role) {
        this.role = role;
    }
    public String getRole() {
        return role;
    }
}
