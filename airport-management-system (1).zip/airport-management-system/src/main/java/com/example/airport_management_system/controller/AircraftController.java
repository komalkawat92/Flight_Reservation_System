package com.example.airport_management_system.controller;

import com.example.airport_management_system.dto.AircraftDto;
import com.example.airport_management_system.dto.PageResponse;
import com.example.airport_management_system.service.AircraftService;
import com.example.airport_management_system.util.FilterBuilderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.coyote.BadRequestException;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/aircrafts")
@Tag(name = "Aircraft API")
public class AircraftController {

    private final AircraftService aircraftService;
    private final FilterBuilderService filterBuilderService;

    public AircraftController(AircraftService aircraftService, FilterBuilderService filterBuilderService) {
        this.aircraftService = aircraftService;
        this.filterBuilderService = filterBuilderService;
    }

    @Operation(summary = "Get all aircraft")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved list of aircraft"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @GetMapping("private/v1/all")
    @PreAuthorize("@apiSecurity.hasAdminRole()")
    public ResponseEntity<PageResponse<AircraftDto>> getAllAircrafts(@RequestParam(value = "page", defaultValue = "0") int page,
                                                                     @RequestParam(value = "size", defaultValue = "20") int size,
                                                                     @RequestParam(required = false, defaultValue = "model") String sortBy,
                                                                     @RequestParam(required = false, defaultValue = "1") String order) throws BadRequestException {
        PageRequest pageable = filterBuilderService.getPageable(size, page, sortBy, order);
        return ResponseEntity.ok(aircraftService.getAllAircrafts(pageable));
    }

    @Operation(summary = "Get an aircraft by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved aircraft"),
            @ApiResponse(responseCode = "404", description = "Aircraft not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @GetMapping("private/v1/get/{aircraftId}")
    @PreAuthorize("@apiSecurity.hasAdminRole()")
    public ResponseEntity<AircraftDto> getAircraftById(@PathVariable Long aircraftId) {
        return ResponseEntity.ok(aircraftService.getAircraftById(aircraftId));
    }

    @Operation(summary = "Create or update an aircraft")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created or updated aircraft"),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PostMapping("private/v1/create-update")
    @PreAuthorize("@apiSecurity.hasAdminRole()")
    public ResponseEntity<AircraftDto> createOrUpdateAircraft(@RequestBody AircraftDto aircraft,
                                                              @RequestParam(required = false) Long aircraftId) {
        return ResponseEntity.ok(aircraftService.createOrUpdateAircraft(aircraft, aircraftId));
    }

    @Operation(summary = "Delete an aircraft by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Successfully deleted aircraft"),
            @ApiResponse(responseCode = "404", description = "Aircraft not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @DeleteMapping("private/v1/delete/{aircraftId}")
    @PreAuthorize("@apiSecurity.hasAdminRole()")
    public ResponseEntity<String> deleteAircraft(@PathVariable Long aircraftId) {
        return ResponseEntity.ok(aircraftService.deleteAircraft(aircraftId));
    }
}
