package com.example.airport_management_system.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.airport_management_system.entity.Airport;

import java.util.Optional;

public interface AirportRepository extends JpaRepository<Airport, Long> {

    Optional<Airport> findByAirportId(Long airportId);
}