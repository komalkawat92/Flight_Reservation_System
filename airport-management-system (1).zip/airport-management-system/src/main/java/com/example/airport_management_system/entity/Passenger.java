package com.example.airport_management_system.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Passenger {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long passengerId;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String passport;
    private String email;
    private String address;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "booking_id")
	@JsonIgnore
	private FlightBooking flightBooking;
}
