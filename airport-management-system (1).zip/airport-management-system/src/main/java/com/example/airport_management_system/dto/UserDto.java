package com.example.airport_management_system.dto;

import com.example.airport_management_system.entity.UserProfile;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Unique identifier for the user.", example = "1", hidden = true)
    private Long userId;

    @Schema(description = "The user's first name.", example = "John")
    private String firstName;

    @Schema(description = "The user's middle name.", example = "D.")
    private String middleName;

    @Schema(description = "The user's last name.", example = "Doe")
    private String lastName;

    @Schema(description = "The username chosen by the user.", example = "johndoe")
    private String username;

    @Schema(description = "The user's email address.", example = "johndoe@example.com")
    private String email;

    @Schema(example = "Test@1234")
    private String password;

    @Schema(hidden = true)
    @JsonFormat(pattern = "dd-MM-yyyy")
    private Date createdAt;

    @Schema(hidden = true)
    @JsonFormat(pattern = "dd-MM-yyyy")
    private Date updatedAt;

    @Schema(description = "A list of user profiles associated with this user.")
    private List<UserProfileDto> userProfiles;
}
