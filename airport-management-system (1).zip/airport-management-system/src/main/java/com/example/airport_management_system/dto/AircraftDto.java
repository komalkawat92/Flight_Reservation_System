package com.example.airport_management_system.dto;

import com.example.airport_management_system.entity.Feedback;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AircraftDto {
    @Schema(description = "Unique identifier of the aircraft", example = "101",hidden = true)
    private Long aircraftId;

    @Schema(description = "Manufacturer of the aircraft", example = "Boeing")
    private String manufacturer;

    @Schema(description = "Model of the aircraft", example = "737 MAX 8")
    private String model;

    @Schema(description = "Passenger capacity of the aircraft", example = "162")
    private int capacity;

    @Schema(description = "Registration number of the aircraft", example = "N12345")
    private String registrationNumber;

    @Schema(hidden = true)
    private List<FeedbackDto> feedbacks;

}
