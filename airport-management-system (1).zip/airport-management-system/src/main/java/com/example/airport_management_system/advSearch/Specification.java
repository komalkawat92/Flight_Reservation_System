package com.example.airport_management_system.advSearch;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Slf4j
public class Specification implements org.springframework.data.jpa.domain.Specification<Object> {
    private final SearchCriteria searchCriteria;

    public Specification(final SearchCriteria searchCriteria) {
        super();
        this.searchCriteria = searchCriteria;
    }

    @Override
    public Predicate toPredicate(Root<Object> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
        QueryHelper queryHelper = new QueryHelper();
        List<String> parentList = searchCriteria.getValue();

        if (searchCriteria.getField().equals("departureCity")) {
            return cb.in(queryHelper.getFrom(searchCriteria, root).<String>get("city")).value(parentList);
        }

        if (searchCriteria.getField().equals("destinationCity")) {
            return cb.in(queryHelper.getFrom(searchCriteria, root).<String>get("city")).value(parentList);
        }
        return null;
    }
}
